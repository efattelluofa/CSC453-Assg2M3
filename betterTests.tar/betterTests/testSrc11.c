int testFunc(int arg1, int arg2, int arg3, int testFunc) {
    int hello;
}
