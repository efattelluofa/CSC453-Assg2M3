int newVar1;
int newVar2;

int testFunc(int newVar1) {
    int newVar2;
    testFunc();
}

/*int newVar1;*/
/*int newVar2;*/

int testFunc2(int newVar1) {
    int newVar2;
    testFunc();
}
/*int newVar1;*/
/*int newVar2;*/
