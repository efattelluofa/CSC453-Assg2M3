int x;

int x;  /* << x is multiply declared */
