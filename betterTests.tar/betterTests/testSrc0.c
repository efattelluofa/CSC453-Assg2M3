int twice, arg1;
int arg2, arg1;

int testFunc(int arg1, int arg2) {
    int hello, twice;
    int goodbye;
    testFunc();
    testFunc();
}
