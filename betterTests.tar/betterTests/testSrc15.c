int testVar;

int f() {
    testVar();
}
