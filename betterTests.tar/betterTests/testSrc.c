/*
 * A sample G1 program
*/

int a() {
  int x, y, z;
}
int p, q, q;

int b(int u, int v) {
  int x, y, z;

  a( );
