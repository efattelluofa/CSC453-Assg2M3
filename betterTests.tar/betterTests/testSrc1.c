int testFunc(int arg1, int arg1) {
    int hello;
}
