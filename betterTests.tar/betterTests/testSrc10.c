int testVar;
int testFunc(int arg1, int arg2, int arg3) {
    int testFunc;
    int testVar;
    int hello;
    testVar();
}
