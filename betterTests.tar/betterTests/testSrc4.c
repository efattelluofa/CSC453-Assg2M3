int testFunc() {
    int hello;
    int bye;
}

int testFunc2() {
    int hello;
    int bye;
    int hello;
}
