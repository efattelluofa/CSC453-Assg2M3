int testFunc() {
    int hello;
    int bye;
}

int testFunc() {
    int hello;
    int bye;
    int hello;
}
