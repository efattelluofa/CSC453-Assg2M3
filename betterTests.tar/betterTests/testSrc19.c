int var1, var2, var3;

int testFunc() {
    int var1, var2;
}

int testFunc2() {
    testFunc();
}

int var1;
