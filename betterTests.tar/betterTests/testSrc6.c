int g2() {

}

int f() {
    g();
}

int g() {}
