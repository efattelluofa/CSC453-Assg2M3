int hello() {
    int goodbye;
    hello();
    hello();
}
