int nothing;
int f() {
    int nothing;
}
int f;

int g() {
    int nothing;
}
