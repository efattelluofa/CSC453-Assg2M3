int hello;
int bye;
int hello() {

}
