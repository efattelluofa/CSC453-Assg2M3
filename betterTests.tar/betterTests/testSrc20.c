int nothing;
int testFunc(int arg2, int arg4) {
    int nothing;
    int arg0, arg5, arg1;
    int arg6;
    testFunc();
}

int arg0, arg2, arg6;
int arg4;

int testFunc2(int nothing, int arg10, int arg1) {
    testFunc();
}
