int testFunc() {
    int var1, var2, var3;
    int var4, var5, var6;
    testFunc();
    testFunc();
}

int testNothing() {
    int var2, var1, var3;
    int var4, var5, var6;
    testFunc();
    testNothing();
    testFunc();
}
