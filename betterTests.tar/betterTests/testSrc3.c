int hi;
int hello() {
    int hi;
}

int hello;
